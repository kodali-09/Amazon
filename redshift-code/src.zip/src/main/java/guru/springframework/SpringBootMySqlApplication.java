package guru.springframework;

import com.amazon.spark.QMRReport$;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootMySqlApplication {

	public static void main(String[] args) {
		QMRReport$.MODULE$.createQMRReport();
		SpringApplication.run(SpringBootMySqlApplication.class, args);
	}
}
