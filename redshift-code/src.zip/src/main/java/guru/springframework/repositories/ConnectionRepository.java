package guru.springframework.repositories;

import guru.springframework.domain.Connections;
import guru.springframework.domain.Sensor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;


public interface ConnectionRepository extends CrudRepository<Connections, Long> {

}