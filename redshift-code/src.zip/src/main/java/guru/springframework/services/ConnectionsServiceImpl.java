package guru.springframework.services;

import guru.springframework.commands.SensorForm;
import guru.springframework.converters.SensorFormToSensor;
import guru.springframework.domain.Sensor;
import guru.springframework.repositories.ConnectionRepository;
import guru.springframework.repositories.SensorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by jt on 1/10/17.
 */
@Service
public class ConnectionsServiceImpl implements ConectionsService {

	private ConnectionRepository connectionRepository;

}
