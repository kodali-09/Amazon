package guru.springframework.services;

import guru.springframework.commands.SensorForm;
import guru.springframework.domain.Sensor;

import java.util.List;

/**
 * Created by jt on 1/10/17.
 */
public interface ConectionsService {

}
